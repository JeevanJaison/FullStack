package com.example.MongodbDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodbDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
